import { useState } from 'react'
import './App.css'
import Forecast from './components/forecast'
import useWeather from './hooks/useWeather'

// https://codeshare.io/5zoNlj
function App() {
  const [count, setCount] = useState(0)
  const { tomorrowForecast, error, isLoading } = useWeather()


  function increment() {
    setCount(count + 1)
  }

  let rainHours = tomorrowForecast.filter(hourData => hourData.chance_of_rain > 20).map(hourData => new Date(hourData.time).getHours())

  return (
    <div className='App'>
      <h1>Tomorrow Forecase</h1>

      {
        isLoading ? <p>Loading...</p> :
          error ? <p>{error}</p> :
            <>
              <h4>Rain Hours (having {'>'}20% chance of rain): {rainHours.join(', ')}</h4>
              <Forecast forecastData={tomorrowForecast} />
              <button onClick={increment}>Count: {count}</button>
            </>
      }

    </div>
  )
}

export default App
