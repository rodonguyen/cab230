


function Forecast({forecastData}) {
    return <>
        {forecastData.map((data, index) => {
            return <div key={`hour-${index}`}>
                <h4>Time: {data.time}</h4>
                <p>Temperature: {data.temperature}, UV index: {data.uv}, Visual (km): {data.visual}, Chance of rain: {data.chance_of_rain}%</p>
            </div>
        })}
    </>
}

export default Forecast