const API_KEY = 'd6b2a0902d714b44b39131823261603';

function getForecastByQuery(q) {
    const url = `https://api.weatherapi.com/v1/forecast.json?q=${q}&key=${API_KEY}&days=2`;
    return fetch(url)
        .then((res) => res.json())
        .then((response) => {
            let hourlyData = response.forecast.forecastday[1].hour; // array of hourly forecast data
            let shortenedData = hourlyData.map(data => ({
                temperature: data.temp_c,
                uv: data.uv,
                visual: data.vis_km,
                time: data.time,
                chance_of_rain: data.chance_of_rain
            }))
            return shortenedData
        })
        .catch((error) => {
            console.error("Caught error: ", error);
            throw error;
        });
}

export default getForecastByQuery;