import { useEffect, useState } from 'react'
import getForecastByQuery from '../api/weather'


// callback hook: provide error, loading, returned data
function useWeather() {
  const [tomorrowForecast, setTomorrowForecast] = useState([])
  const [error, setError] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    getForecastByQuery('Brisbane')
      .then(res => {
        setTomorrowForecast(res)
      })
      .catch(err => setError(err.message))
      .finally(() => setIsLoading(false))
  }, [])

  return {tomorrowForecast, error, isLoading}
}

export default useWeather
