import express from 'express';
import knex from 'knex';
import knexConfig from './knexfile.js';
import cityRouter from './routes/city.js'

const app = express();
const port = 3000;

const db = knex(knexConfig);
app.use((req, res, next) => {
  req.db = db;
  next();
});

// app.get("/knex", (req, res, next) => {
//   req.db.raw("SELECT * FROM world.city")
//   .then(cities => {
//     res.json(cities[0]);
//   })
//   .catch(err => {
//     console.log(err);
//     throw err;
//   });
// });

app.get('/', (req, res) => { // endpoint
  res.send('Hello world!!!!!!');
});

app.use('/city', cityRouter);

app.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});