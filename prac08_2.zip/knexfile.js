export default {
  client: 'mysql2',
  connection: {
    host: '127.0.0.1',
    user: 'mod',
    password: 'mod',
    database: 'world',
  },
};