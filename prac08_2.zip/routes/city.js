import express from 'express';
const router = express.Router();

router.get("/", (req, res, next) => {
  const limit = Math.min(parseInt(req.query.limit, 10) || 50, 100);
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const offset = (page - 1) * limit;

  const order = req.query.order === "desc" ? "desc" : "asc";

  const countQuery = req.db
    .from("city")
    .count({ count: "*" })
    .first();

  const dataQuery = req.db
    .from("city")
    .select("name", "district", "population")
    .orderBy("name", order)
    .limit(limit)
    .offset(offset);

  Promise.all([countQuery, dataQuery])
    .then(([countRow, rows]) => {
      const totalItems = parseInt(countRow.count, 10) || 0;
      const totalPages = totalItems ? Math.ceil(totalItems / limit) : 0;

      res.json({
        error: false,
        message: "Success",
        page,
        limit,
        totalPages,
        cities: rows,
      });
    })
  .catch(err => {
    console.log(err);
    res.status(500).json({ error: true, message: "Error in MySQL query" });
  });
});


router.get("/:countryCode", (req, res, next) => {
  req.db
  .from("city")
  .select("*")
  .where("CountryCode", "=", req.params.countryCode)
  .then((rows) => {
    res.json({ error: false, message: "Success", cities: rows });
  })
  .catch((err) => {
    console.log(err);
    res.status(500).json({ error: true, message: "Error in MySQL query" });
  });
});


// router.get("/abc", (req, res, next) => {
//   res.json({ error: false, message: "Success", cities: ['abc'] });
// });




export default router;