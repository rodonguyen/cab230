import { Container, Button } from "react-bootstrap";
import { useNavigate, useSearchParams } from "react-router-dom";




export default function Product() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const title = searchParams.get("title");

    return (
        <Container>
            <h1>Individual Product</h1>
            <p>The product that you selected was: {title}</p>
            <Button
                variant="info"
                size="sm"
                className="mt-3"
                onClick={() => navigate("/")}
            >
                Back
            </Button>
        </Container>
    );
}