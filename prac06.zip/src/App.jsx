import { useState, useEffect } from 'react'
import './App.css'
import { AllCommunityModule, themeBalham } from 'ag-grid-community';
import { AgGridProvider, AgGridReact } from 'ag-grid-react';
import "bootstrap/dist/css/bootstrap.min.css";
import { Button, Badge, Container } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

function calculateAverage(arr) {
  if (arr.length === 0) {
    return 0; // or handle the error as appropriate
  }
  const sum = arr.reduce((acc, current) => acc + current, 0);
  return sum / arr.length;
}


function App() {
  const [rowData, setRowData] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("https://dummyjson.com/products")
      .then(res => res.json())
      .then(data => {
        let products = data.products;
        products = products.map(p => {
          return {
            title: p.title,
            category: p.category,
            price: p.price,
            rating: p.rating,
            stock: p.stock,
            avgReview: calculateAverage(p.reviews.map(review => review.rating)).toFixed(1)
          }
        })
        setRowData(products)
      })
  }
    , []);

  const table = {
    defaultColDef: {
      filter: "agTextColumnFilter",
      sortable: true
    },
    columns: [
      { headerName: "Title", field: "title", flex: 1.2 },
      { headerName: "Category", field: "category", flex: 0.8 },
      { headerName: "Price ($)", field: "price", flex: 0.5 },
      { headerName: "Rating", field: "rating", flex: 0.5 },
      { headerName: "Remaining Stock", field: "stock", flex: 0.5 },
      { headerName: "Avg Review", field: "avgReview", flex: 0.5 }
    ]
  };

  //////////////////// https://codeshare.io/5P09l7  //////////////////////
  return (
    <>
      <Container>
        <h1>Prac 06 Using AG Grid</h1>
        <p><Badge>{rowData.length}</Badge> products available in the catalogue</p>
        <AgGridProvider modules={[AllCommunityModule]}>
          <div className="ag-grid-container">
            <AgGridReact
              theme={themeBalham}
              columnDefs={table.columns}
              rowData={rowData}
              defaultColDef={table.defaultColDef}
              pagination={true}
              paginationPageSize={16}
              onRowClicked={row => navigate(`/product?title=${row.data.title}`)}
            />
          </div>
        </AgGridProvider>

        <Button
          variant="info"
          size="sm"
          className="mt-3"
          href="https://dummyjson.com/docs/"
          target="_blank"
        >
          Go to DummyJSON API
        </Button>
      </Container>
    </>
  )
}

export default App
