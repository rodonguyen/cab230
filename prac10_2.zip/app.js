import express from 'express';
import knex from 'knex';
import knexConfig from './knexfile.js';
import cityRouter from './routes/city.js';
import userRouter from './routes/user.js'

const app = express();
const port = 3000;

const db = knex(knexConfig);

app.use(express.json());
app.use((req, res, next) => {
  req.db = db;
  next();
});

app.use('/city', cityRouter);
app.use('/user', userRouter);

// TODO: need to delete this after testing, don't submit this code
// app.get("/knex", (req, res, next) => {
//   req.db.raw("SELECT * from country").then(country => {
//     res.send("Country data: " + JSON.stringify(country[0]));
//   })
//   .catch(err => {
//     console.log(err);
//     throw err;
//   });
// });

// app.get('/', (req, res) => {
//   res.send('Hello world');
// });


app.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});


// https://codeshare.io/G8B0YZ