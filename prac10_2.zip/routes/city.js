import express from 'express';
import authenticate from '../middlewares/authenticate.js';
const router = express.Router();


// query has limit
router.get("/", (req, res, next) => {
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 50, 1), 200);
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const offset = (page - 1) * limit;
  let order = req.query.order;

  if (order && order.toLowerCase() !== "asc" && order !== "desc") {
    order = "asc";
  }

  const countQuery = req.db('city').count('* as total').first();
  const citiesQuery = req.db
    .from("city")
    .select("name", "district")
    .limit(limit)
    .offset(offset)
    .orderBy("name", order);

  Promise.all([countQuery, citiesQuery])
    .then(([countRow, rows]) => {
      res.json({
        error: false,
        message: "Success",
        page,
        limit,
        total: Number(countRow.total),
        cities: rows,
      });
  })
  .catch(err => {
    console.log(err);
    res.status(500).json({ error: true, message: "Error in MySQL query" });
  });
});

router.get("/:countryCode", (req, res, next) => {
  req.db
  .from("city")
  .select("*")
  .where("CountryCode", "=", req.params.countryCode)
  .then((rows) => {
    res.json({ error: false, message: "Success", cities: rows });
  })
  .catch((err) => {
    console.log(err);
    res.status(500).json({ error: true, message: "Error in MySQL query" });
  });
});

router.put("/", authenticate, async (req, res, next) => {
  
  res.status(201).json({ error: false, message: "City updated successfully" });
});

export default router;