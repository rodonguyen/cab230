import express from 'express';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv'
import argon2 from 'argon2'
dotenv.config();

const router = express.Router();

router.post('/login', async (req, res, next) => {
    // 1. Retrieve email and password from req.body
  const { email, password } = req.body ?? {};

  // Verify body
  if (!email || !password) {
    res.status(400).json({
      error: true,
      message: "Request body incomplete - email and password needed"
    });
    return;
  }

  // 2. Determine if user already exists in table
  const users = await req.db.from("users").select("*").where("email", "=", email);
  if (users.length === 0) {
    res.status(400).json({
      error: true,
      message: "Email or password is incorrect"
    });
    return;
  }

  const { hash } = users[0];
  const isMatch = await argon2.verify(hash, password);
  if (!isMatch) {
    res.status(400).json({
      error: true,
      message: "Email or password is incorrect"
    });
    return;
  }

  const expiresIn = 60 * 10; // exp in 10 minutes
  const exp = Math.floor(Date.now() / 1000) + expiresIn;
  const token = jwt.sign({ exp, email }, process.env.JWT_SECRET);
  res.json({
    token,
    token_type: "Bearer",
    expiresIn
  });
});

router.post('/register', async (req, res, next) => {
  // 1. Retrieve email and password from req.body
  const {email, password} = req.body ?? {};

  // Verify body
  if (!email || !password) {
    res.status(400).json({
      error: true,
      message: "Request body incomplete - email and password needed"
    });
    return;
  }
  
  // 2. Determine if user already exists in table
  console.log(`Checking if user with email ${email} exists`);
  const queryUsers = await req.db.from("users").select("*").where("email", "=", email);
  // queryUsers.then(users => {
  //   if (users.length > 0) {
  //     console.log("User already exists");
  //     return;
  //   }

  //   console.log("No matching users");
  // });

  if (queryUsers.length > 0) {
    res.status(400).json({
      error: true,
      message: "User already exists"
    });
    return;
  }

  // 2.2 If user does not exist, insert into table
  console.log(`User with email ${email} does not exist, creating new user`);
  const hash = await argon2.hash(password);
  
  try {
    const result = await req.db.from("users").insert({ email, hash }); // {email: email, hash: hash}
  } 
  catch {
    res.status(500).json({
      error: true,
      message: "Failed to create user"
    });
    return;
  }

  res.status(201).json({
    error: false,
    message: "User created successfully"
  });
  return
});


export default router;